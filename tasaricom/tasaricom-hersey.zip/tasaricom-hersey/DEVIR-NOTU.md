# tasarıcom devir notu

Bu not kaynak. Tahminle yeni ürün uydurma. Önce `tasaricom/` kodunu oku, sonra istenen işi yap.

## Ürün

Türkçe bir SaaS paneli. İşletme özel güne girer, kendi logosu ve renkleriyle görsel alır. Beğenmezse varyasyon ister ya da aynı işi editöre bırakır. Editör yerleşimi düzeltir, not düşer, teslim eder. Müşteri onaylar.

Bu bir sosyal medya takvimi veya analitik aracı değil. İlham alınan ekran düzeni Puhu Social'a benzer, iş modeli on-demand marka görseli.

Hedef kullanıcı: kafe, mağaza, klinik gibi tek işletme. Ajans paketi çoklu markayı "yakında" diye yazar. Bu sürüm tek marka tutar.

Dil: arayüz Türkçe. Kod ve dosya adları İngilizce kalabilir.

## Bu pakette ne var

- `tasaricom/` kaynak kod. `node_modules` yok. `npm install` ile kurulur.
- `ekran-goruntuleri/` 23 JPG. Açık tema 01–12, koyu tema 13–22. Dosya adlarının listesi `ekran-goruntuleri/OKU.txt`.
- `videolar/` üç ekran kaydı. Claude'a video yüklenemiyorsa fotoğraflar yeterli.

## Repo

- GitHub: zeusckk/mamyizm
- PR: https://github.com/zeusckk/mamyizm/pull/1
- Dal: cursor/tasaricom-panel-6e3e
- Uygulama yalnız `tasaricom/` altında.
- Asıl repodaki `frontend/`, `backend/`, `tests/` başka ürün. Onlara dokunma. Bu pakette yoklar.

Çalıştırma:

    cd tasaricom
    npm install
    npm run dev

Vite, http://127.0.0.1:5173. Kontrol: `npx tsc --noEmit`. Ayrı test dosyası yok.

## Yığın

React 19, Vite 7, TypeScript 5, react-router-dom 7. UI kütüphanesi yok. Stil tek dosya: `src/styles.css`. Durum: React context + useReducer. Kalıcılık: localStorage anahtarı `tasaricom.v1`. Sunucu, auth, ödeme ve yapay zeka modeli yok.

## Rotalar

Hepsi `Shell` içinde.

- `/` Stüdyo
- `/studio/:id` üretim sahnesi
- `/takvim` özel günler
- `/marka` marka özeti
- `/marka/kimlik` kimlik formu
- `/tasarimlar` galeri
- `/hesap` paket, hak, fatura
- `/planlar` paket seçimi
- `/editor` editör kuyruğu

Menü: Stüdyo, Özel günler, Marka, Tasarımlarım, Hesap. Atölye başlığı altında Editör kuyruğu. Bekleyen iş sayısı rozeti `status === 'editor'` olanlardan gelir.

## Dosyalar

- `src/types.ts` Brand, Design, Invoice, Bill, AppState
- `src/data.ts` özel günler, paketler, sektör/ses listeleri, tarih ve altyazı yardımcıları
- `src/store.tsx` reducer, seed, localStorage, tema
- `src/poster.ts` SVG motoru. Dört şablon: Koyu çerçeve, Davet, Afiş, Renk bloğu
- `src/PosterFrame.tsx` canlı önizleme
- `src/files.ts` logo okur. PNG, JPG, WEBP. Üst sınır 700 KB. data URL
- `src/Shell.tsx` yan menü, başlangıç çubuğu, paket kartı, tema, deneme şeridi
- `src/pages/*` ekranlar
- `src/styles.css` cam tasarım sistemi

## Durum katmanı

`useStore()` aksiyonları: createDesign, revise, vary, toggleLogo, setFormat, setCaption, sendToEditor, approve, deliver, saveBrand, saveInvoice, choosePlan, setTheme, reset.

Akış:

1. createDesign kredi düşer, tasarım `pending: true` olur, 1300 ms sonra `finish` altyazı ve stüdyo cevabını yazar.
2. revise notu `revisionLine` yapar, varyasyonu artırır, durumu taslağa çeker.
3. vary yalnız yerleşim indeksini artırır.
4. sendToEditor planın editör hakkını kontrol eder, `editorUsed` artar.
5. deliver durumu `delivered` yapar, editör notunu sohbete yazar.
6. approve durumu `approved` yapar.
7. choosePlan krediyi plan limitine çeker, editör sayacını sıfırlar, ödemesiz bir demo fatura satırı ekler. Yıllık tutar `monthly * 10` (2 ay bedava).
8. reset `tasaricom.v1` anahtarını siler ve seed'e döner.

Şema değişirse `AppState.v` değerini yükselt ve `load()` eski kaydı seed'e düşürsün. Sessizce kırık state okuma.

Seed marka: Mola Kahve, slogan "Bugün de uğra.", sektör Kafe & Restoran, renkler #243126 ve #E6A15C, ses Samimi + Sıcak. Plan deneme, 12 kredi, 1 editör hakkı, deneme bitişi bugün + 7 gün.

## Görsel motor

`posterSvg(design, brand, plan, uid)` saf SVG döner. Ölçüler: 4:5 = 800×1000, 1:1 = 1000, 9:16 = 900×1600, 16:9 = 1600×900.

Şablon seçimi `templateIndex`: milli 0, kutlama 1, ticari 2, özel 3. Dramatik ışık 0'a, Cesur veya Eğlenceli ses 2'ye, Düz renk 3'e, milli olmayan Stüdyo 1'e çeker. `variation` bunun üstüne eklenir, mod 4.

Başlık `occasion.short` ile brief'ten gelir, 42 karakterde kesilir. Alt satır revision notu, yoksa slogan, yoksa gün başlığı. Logo varsa data URL, yoksa iki harf. Deneme planında küçük "tasarıcom" filigranı vardır. Koyu çerçevede filigran sol altta durur, sağ alttaki logoyla çarpışmasın. Metin rengi `readable()` ile luminance'dan seçilir.

İndirme `downloadPoster`. Yalnız SVG. PNG veya JPG yok.

## Özel günler

Tarihler `data.ts` içinde sabit. 2026–2027. Dini günler Diyanet 2027 takvimine göre yazıldı:

- Ramazan Bayramı 9 Mart 2027 (8 Mart arife)
- Kurban Bayramı 16 Mayıs 2027. 19 Mayıs bayramın dördüncü günüyle çakışır

Tarihsiz günler: Firma yıldönümü, Kampanya, Serbest tasarım. Takvim hafta ve ay görünümü var. Kullanıcının kendi gününü eklediği form yok.

## Paketler

- Deneme: 0 TL, 12 taslak, 1 editör, SVG'de imza
- Atölye: 1.490 TL/ay, 40 taslak, 4 editör
- Marka: 2.490 TL/ay, 100 taslak, 12 editör, önerilen
- Ajans: 4.990 TL/ay, 280 taslak, 40 editör, çoklu marka yok

Ödeme alınmaz. Kart formu yok.

## Görünüm

Cam. Düz beyaz kartlara dönme.

Açık: `--glass: rgba(255,255,255,0.42)`, blur `blur(18px) saturate(1.6)`, gövde `body::before` ile sabit renkli gradyan.
Koyu: `--glass: rgba(22,16,34,0.48)`, ayrı koyu gradyan.
Vurgu: `#ff5a3c`.
Tema: `system | light | dark`. `document.documentElement.dataset.theme`.
Kırılımlar: 1100px ve 860px. `prefers-reduced-motion` ve `prefers-reduced-transparency` var.

Yeni ekran da `.card`, `.panel`, `.pane`, `.chip` ile aynı camı kullansın. Yeni bir tasarım dili açma.

Ekranların hali `ekran-goruntuleri/` klasöründe.

## Bilerek yapılmayanlar

- Yapay zeka görsel modeli bağlı değil. "Üret" deyince şablon SVG kurulur.
- Müşteri ve editör aynı tarayıcı, aynı state. Ayrı rol yok.
- Auth, veritabanı, çoklu kullanıcı yok.
- Gerçek ödeme ve e-fatura yok. Fatura alanları sadece localStorage.
- Ajans çoklu marka yok.
- Özel gün ekleme formu yok.
- PNG, JPG, sosyal paylaşım, zamanlama, analitik yok.
- "Ürün var" ve "Mekân var" seçenekleri poster kompozisyonunu gerçekten fotoğrafla doldurmaz. Şu an yazı ve renk şablonu.

## Bir işe başlamadan

1. İstenen iş bu nottaki ürünle aynı mı, kontrol et.
2. `tasaricom/src` içinde ilgili dosyayı oku.
3. Davranışı bozma: kredi, editör hakkı, pending 1300 ms, deneme filigranı, localStorage anahtarı.
4. Metinleri Türkçe ve kısa tut. Mevcut cümle tonunu kopyala.
5. `npx tsc --noEmit` geçmeden bitirme.
6. Şema değişirse versiyonu yükselt.

## Sıradaki iş için açık kapı

Kullanıcı bir sonraki işi ayrıca söyleyecek. O işi söylemeden backend, ödeme veya model bağlama. İsterse görsel modeli, `createDesign` içindeki 1300 ms'lik `finish` yerine geçecek şekilde bağla. Poster sözleşmesi aynı kalsın: marka renkleri, logo, gün, format, varyasyon. Model cevabı gelene kadar mevcut SVG yer tutucu olarak kalsın.
